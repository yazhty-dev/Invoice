import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { 
  Plus, 
  CreditCard, 
  DollarSign, 
  TrendingUp,
  TrendingDown,
  Edit,
  Trash2
} from 'lucide-react';

interface Account {
  id: string;
  name: string;
  type: 'cash' | 'bank';
  balance: number;
  accountNumber?: string;
  bankName?: string;
}

const Accounts = () => {
  const [accounts, setAccounts] = useState<Account[]>([
    {
      id: '1',
      name: 'Cash on Hand',
      type: 'cash',
      balance: 45000
    },
    {
      id: '2',
      name: 'Primary Bank Account',
      type: 'bank',
      balance: 125000,
      accountNumber: '****1234',
      bankName: 'State Bank of India'
    },
    {
      id: '3',
      name: 'Business Savings',
      type: 'bank',
      balance: 78000,
      accountNumber: '****5678',
      bankName: 'ICICI Bank'
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newAccount, setNewAccount] = useState({
    name: '',
    type: 'cash' as 'cash' | 'bank',
    balance: 0,
    accountNumber: '',
    bankName: ''
  });

  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0);
  const cashBalance = accounts.filter(acc => acc.type === 'cash').reduce((sum, acc) => sum + acc.balance, 0);
  const bankBalance = accounts.filter(acc => acc.type === 'bank').reduce((sum, acc) => sum + acc.balance, 0);

  const handleAddAccount = () => {
    if (!newAccount.name || newAccount.balance < 0) {
      toast({
        title: "Invalid Input",
        description: "Please provide valid account details.",
        variant: "destructive"
      });
      return;
    }

    const account: Account = {
      id: Date.now().toString(),
      name: newAccount.name,
      type: newAccount.type,
      balance: newAccount.balance,
      ...(newAccount.type === 'bank' && {
        accountNumber: newAccount.accountNumber,
        bankName: newAccount.bankName
      })
    };

    setAccounts(prev => [...prev, account]);
    setNewAccount({
      name: '',
      type: 'cash',
      balance: 0,
      accountNumber: '',
      bankName: ''
    });
    setIsDialogOpen(false);

    toast({
      title: "Account Added",
      description: `${account.name} has been added successfully.`,
    });
  };

  const handleDeleteAccount = (id: string) => {
    setAccounts(prev => prev.filter(acc => acc.id !== id));
    toast({
      title: "Account Deleted",
      description: "Account has been removed successfully.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-primary">Accounts</h1>
          <p className="text-muted-foreground">Manage your cash and bank accounts</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add New Account</DialogTitle>
              <DialogDescription>
                Create a new cash or bank account to track your finances.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="accountName">Account Name</Label>
                <Input
                  id="accountName"
                  value={newAccount.name}
                  onChange={(e) => setNewAccount(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Main Cash Register"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountType">Account Type</Label>
                <select
                  id="accountType"
                  value={newAccount.type}
                  onChange={(e) => setNewAccount(prev => ({ ...prev, type: e.target.value as 'cash' | 'bank' }))}
                  className="w-full px-3 py-2 border border-input rounded-md"
                >
                  <option value="cash">Cash</option>
                  <option value="bank">Bank Account</option>
                </select>
              </div>

              {newAccount.type === 'bank' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name</Label>
                    <Input
                      id="bankName"
                      value={newAccount.bankName}
                      onChange={(e) => setNewAccount(prev => ({ ...prev, bankName: e.target.value }))}
                      placeholder="e.g., State Bank of India"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number (Last 4 digits)</Label>
                    <Input
                      id="accountNumber"
                      value={newAccount.accountNumber}
                      onChange={(e) => setNewAccount(prev => ({ ...prev, accountNumber: e.target.value }))}
                      placeholder="1234"
                      maxLength={4}
                    />
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="balance">Initial Balance</Label>
                <Input
                  id="balance"
                  type="number"
                  value={newAccount.balance}
                  onChange={(e) => setNewAccount(prev => ({ ...prev, balance: Number(e.target.value) }))}
                  placeholder="0"
                />
              </div>

              <Button onClick={handleAddAccount} className="w-full">
                Add Account
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalBalance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Across all accounts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cash Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">₹{cashBalance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Cash on hand</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bank Balance</CardTitle>
            <CreditCard className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">₹{bankBalance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Bank accounts</p>
          </CardContent>
        </Card>
      </div>

      {/* Accounts List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts.map((account) => (
          <Card key={account.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {account.type === 'cash' ? (
                    <DollarSign className="h-5 w-5 text-success" />
                  ) : (
                    <CreditCard className="h-5 w-5 text-primary" />
                  )}
                  <CardTitle className="text-lg">{account.name}</CardTitle>
                </div>
                <Badge variant={account.type === 'cash' ? 'default' : 'secondary'}>
                  {account.type.toUpperCase()}
                </Badge>
              </div>
              {account.type === 'bank' && (
                <CardDescription>
                  {account.bankName} • ****{account.accountNumber}
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Current Balance</p>
                  <p className="text-2xl font-bold">₹{account.balance.toLocaleString()}</p>
                </div>
                
                <div className="flex items-center justify-between pt-2">
                  <div className="flex space-x-1">
                    <Button variant="outline" size="sm">
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleDeleteAccount(account.id)}
                      className="text-danger hover:text-danger"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    {account.balance > 50000 ? (
                      <TrendingUp className="h-4 w-4 text-success" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-warning" />
                    )}
                    <span>{account.balance > 50000 ? 'High' : 'Low'}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Accounts;