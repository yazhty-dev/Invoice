import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { toast } from '@/hooks/use-toast';
import GoogleSheetsIntegration from '@/components/GoogleSheetsIntegration';
import { 
  Download, 
  FileText, 
  Calendar as CalendarIcon, 
  Filter,
  Table as TableIcon,
  Settings as SettingsIcon
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ReportData {
  id: string;
  date: string;
  type: string;
  description: string;
  income: number;
  expense: number;
  balance: number;
}

const Reports = () => {
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [reportType, setReportType] = useState<string>('all');
  const [isGenerating, setIsGenerating] = useState(false);

  // Sample report data
  const sampleData: ReportData[] = [
    {
      id: '1',
      date: '2025-01-15',
      type: 'Income',
      description: 'Printing Services - Order #001',
      income: 5500,
      expense: 0,
      balance: 5500
    },
    {
      id: '2',
      date: '2025-01-16',
      type: 'Expense',
      description: 'Paper Stock Purchase',
      income: 0,
      expense: 2800,
      balance: 2700
    },
    {
      id: '3',
      date: '2025-01-17',
      type: 'Income',
      description: 'Frame Installation - Order #002',
      income: 8200,
      expense: 0,
      balance: 10900
    },
    {
      id: '4',
      date: '2025-01-18',
      type: 'Expense',
      description: 'Electricity Bill',
      income: 0,
      expense: 1200,
      balance: 9700
    },
    {
      id: '5',
      date: '2025-01-19',
      type: 'Income',
      description: 'Digital Printing - Order #003',
      income: 3400,
      expense: 0,
      balance: 13100
    }
  ];

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    
    // Simulate report generation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast({
      title: "Report Generated",
      description: "Your financial report has been generated successfully.",
    });
    
    setIsGenerating(false);
  };

  const handleDownloadPDF = () => {
    // In a real app, this would generate and download a PDF
    toast({
      title: "PDF Download",
      description: "PDF report download will be implemented with backend integration.",
    });
  };

  const handleDownloadExcel = () => {
    // In a real app, this would generate and download an Excel file
    toast({
      title: "Excel Download",
      description: "Excel report download will be implemented with backend integration.",
    });
  };

  const handleSyncGoogleSheets = () => {
    toast({
      title: "Google Sheets Sync",
      description: "Data will be synced with Google Sheets integration.",
    });
  };

  const filteredData = sampleData.filter(item => {
    if (reportType === 'income') return item.type === 'Income';
    if (reportType === 'expense') return item.type === 'Expense';
    return true;
  });

  const totalIncome = filteredData.reduce((sum, item) => sum + item.income, 0);
  const totalExpense = filteredData.reduce((sum, item) => sum + item.expense, 0);
  const netAmount = totalIncome - totalExpense;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-primary">Reports & Integration</h1>
          <p className="text-muted-foreground">Generate reports and sync with Google Sheets</p>
        </div>
      </div>

      {/* Tabs for Reports and Google Sheets Integration */}
      <Tabs defaultValue="reports" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Financial Reports
          </TabsTrigger>
          <TabsTrigger value="integration" className="flex items-center gap-2">
            <SettingsIcon className="h-4 w-4" />
            Google Sheets
          </TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-6">
          {/* Report Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Report Configuration</CardTitle>
          <CardDescription>Set filters and parameters for your report</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Date Range */}
            <div className="space-y-2">
              <Label>Start Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "justify-start text-left font-normal",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "PPP") : "Pick start date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>End Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "justify-start text-left font-normal",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "PPP") : "Pick end date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Report Type */}
            <div className="space-y-2">
              <Label>Report Type</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Transactions</SelectItem>
                  <SelectItem value="income">Income Only</SelectItem>
                  <SelectItem value="expense">Expense Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleGenerateReport} disabled={isGenerating}>
              <Filter className="h-4 w-4 mr-2" />
              {isGenerating ? "Generating..." : "Generate Report"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Report Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">₹{totalIncome.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Expense</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">₹{totalExpense.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Net Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netAmount >= 0 ? 'text-success' : 'text-danger'}`}>
              ₹{netAmount.toLocaleString()}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Data Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Financial Report</CardTitle>
            <CardDescription>Detailed transaction report for the selected period</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleDownloadPDF}>
              <FileText className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownloadExcel}>
              <Download className="h-4 w-4 mr-2" />
              Download Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Date</th>
                  <th className="text-left p-3">Type</th>
                  <th className="text-left p-3">Description</th>
                  <th className="text-right p-3">Income</th>
                  <th className="text-right p-3">Expense</th>
                  <th className="text-right p-3">Running Balance</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((item) => (
                  <tr key={item.id} className="border-b hover:bg-muted/50">
                    <td className="p-3">{format(new Date(item.date), 'dd/MM/yyyy')}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        item.type === 'Income' 
                          ? 'bg-success/10 text-success' 
                          : 'bg-warning/10 text-warning'
                      }`}>
                        {item.type}
                      </span>
                    </td>
                    <td className="p-3">{item.description}</td>
                    <td className="p-3 text-right text-success">
                      {item.income > 0 ? `₹${item.income.toLocaleString()}` : '-'}
                    </td>
                    <td className="p-3 text-right text-warning">
                      {item.expense > 0 ? `₹${item.expense.toLocaleString()}` : '-'}
                    </td>
                    <td className="p-3 text-right font-medium">₹{item.balance.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
        </TabsContent>

        <TabsContent value="integration">
          <GoogleSheetsIntegration />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;