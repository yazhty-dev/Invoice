import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CreditCard, 
  Calendar,
  FileText,
  Download
} from 'lucide-react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface MonthlyData {
  month: string;
  income: number;
  expense: number;
  net: number;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [currentBalance, setCurrentBalance] = useState({
    cash: 45000,
    bank: 125000,
    total: 170000
  });

  // Sample data - In real app, this would come from Google Sheets
  useEffect(() => {
    const sampleData: MonthlyData[] = [
      { month: 'Jan 2025', income: 85000, expense: 62000, net: 23000 },
      { month: 'Feb 2025', income: 92000, expense: 68000, net: 24000 },
      { month: 'Mar 2025', income: 78000, expense: 55000, net: 23000 },
      { month: 'Apr 2025', income: 105000, expense: 72000, net: 33000 },
      { month: 'May 2025', income: 88000, expense: 61000, net: 27000 },
      { month: 'Jun 2025', income: 96000, expense: 70000, net: 26000 },
    ];
    setMonthlyData(sampleData);
  }, []);

  const totalIncome = monthlyData.reduce((sum, data) => sum + data.income, 0);
  const totalExpense = monthlyData.reduce((sum, data) => sum + data.expense, 0);
  const netProfit = totalIncome - totalExpense;

  // Chart data
  const incomeVsExpenseData = {
    labels: monthlyData.map(data => data.month),
    datasets: [
      {
        label: 'Income',
        data: monthlyData.map(data => data.income),
        borderColor: 'hsl(var(--success))',
        backgroundColor: 'hsl(var(--success) / 0.1)',
        tension: 0.4,
      },
      {
        label: 'Expense',
        data: monthlyData.map(data => data.expense),
        borderColor: 'hsl(var(--warning))',
        backgroundColor: 'hsl(var(--warning) / 0.1)',
        tension: 0.4,
      },
    ],
  };

  const netProfitData = {
    labels: monthlyData.map(data => data.month),
    datasets: [
      {
        label: 'Net Profit',
        data: monthlyData.map(data => data.net),
        backgroundColor: monthlyData.map(data => 
          data.net > 0 ? 'hsl(var(--success))' : 'hsl(var(--danger))'
        ),
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value: any) {
            return '₹' + value.toLocaleString();
          }
        }
      }
    }
  };

  const handleSyncToGoogleSheets = async () => {
    const webhookUrl = localStorage.getItem('google_sheets_webhook');
    
    if (!webhookUrl) {
      toast({
        title: "Google Sheets Not Configured",
        description: "Please configure Google Sheets integration in the Reports section first.",
        variant: "destructive"
      });
      return;
    }

    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        mode: "no-cors",
        body: JSON.stringify({
          action: "dashboard_sync",
          timestamp: new Date().toISOString(),
          data: {
            monthlyData: monthlyData,
            currentBalance: currentBalance,
            summary: {
              totalIncome,
              totalExpense,
              netProfit
            }
          }
        }),
      });

      toast({
        title: "Data Synced",
        description: "Dashboard data has been sent to Google Sheets.",
      });
    } catch (error) {
      toast({
        title: "Sync Failed",
        description: "Failed to sync data to Google Sheets.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-primary">Dashboard</h1>
          <p className="text-muted-foreground">Yazh Prints and Frames - Financial Overview</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleSyncToGoogleSheets}>
            <Download className="h-4 w-4 mr-2" />
            Sync to Sheets
          </Button>
          <Button size="sm" onClick={() => navigate('/transactions')}>
            <FileText className="h-4 w-4 mr-2" />
            New Entry
          </Button>
        </div>
      </div>

      {/* Account Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cash Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">₹{currentBalance.cash.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Available cash on hand</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bank Balance</CardTitle>
            <CreditCard className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">₹{currentBalance.bank.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Bank account balance</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{currentBalance.total.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Combined cash + bank</p>
          </CardContent>
        </Card>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">₹{totalIncome.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Last 6 months</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expense</CardTitle>
            <TrendingDown className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">₹{totalExpense.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Last 6 months</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            {netProfit > 0 ? 
              <TrendingUp className="h-4 w-4 text-success" /> : 
              <TrendingDown className="h-4 w-4 text-danger" />
            }
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netProfit > 0 ? 'text-success' : 'text-danger'}`}>
              ₹{netProfit.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">Last 6 months</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Income vs Expense Trend</CardTitle>
            <CardDescription>Monthly comparison of income and expenses</CardDescription>
          </CardHeader>
          <CardContent>
            <Line data={incomeVsExpenseData} options={chartOptions} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Net Profit</CardTitle>
            <CardDescription>Profit/Loss analysis by month</CardDescription>
          </CardHeader>
          <CardContent>
            <Bar data={netProfitData} options={chartOptions} />
          </CardContent>
        </Card>
      </div>

      {/* Monthly Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Financial Summary</CardTitle>
          <CardDescription>Detailed breakdown of monthly performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Month</th>
                  <th className="text-right p-2">Income</th>
                  <th className="text-right p-2">Expense</th>
                  <th className="text-right p-2">Net Profit</th>
                  <th className="text-center p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {monthlyData.map((data, index) => (
                  <tr key={index} className="border-b hover:bg-muted/50">
                    <td className="p-2 font-medium">{data.month}</td>
                    <td className="p-2 text-right text-success">₹{data.income.toLocaleString()}</td>
                    <td className="p-2 text-right text-warning">₹{data.expense.toLocaleString()}</td>
                    <td className={`p-2 text-right font-semibold ${data.net > 0 ? 'text-success' : 'text-danger'}`}>
                      ₹{data.net.toLocaleString()}
                    </td>
                    <td className="p-2 text-center">
                      <Badge variant={data.net > 0 ? "default" : "destructive"}>
                        {data.net > 0 ? 'Profit' : 'Loss'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;