import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { 
  Plus, 
  Calendar as CalendarIcon, 
  DollarSign,
  Upload,
  Save
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface Transaction {
  id: string;
  date: string;
  type: 'income' | 'expense';
  category: string;
  description: string;
  amount: number;
  account: string;
  reference?: string;
}

const Transactions = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [autoSyncToSheets, setAutoSyncToSheets] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [transaction, setTransaction] = useState<Omit<Transaction, 'id'>>({
    date: new Date().toISOString().split('T')[0],
    type: 'income',
    category: '',
    description: '',
    amount: 0,
    account: 'cash',
    reference: ''
  });

  const [recentTransactions] = useState<Transaction[]>([
    {
      id: '1',
      date: '2025-01-15',
      type: 'income',
      category: 'Printing Services',
      description: 'Business cards and brochures - Client ABC',
      amount: 5500,
      account: 'cash',
      reference: 'INV-001'
    },
    {
      id: '2',
      date: '2025-01-16',
      type: 'expense',
      category: 'Supplies',
      description: 'Photo paper and ink cartridges',
      amount: 2800,
      account: 'bank',
      reference: 'PO-045'
    },
    {
      id: '3',
      date: '2025-01-17',
      type: 'income',
      category: 'Frame Installation',
      description: 'Custom frame installation service',
      amount: 8200,
      account: 'cash',
      reference: 'INV-002'
    }
  ]);

  const incomeCategories = [
    'Printing Services',
    'Frame Installation', 
    'Digital Printing',
    'Binding Services',
    'Design Services',
    'Other Income'
  ];

  const expenseCategories = [
    'Supplies',
    'Equipment',
    'Utilities',
    'Rent',
    'Marketing',
    'Transportation',
    'Professional Services',
    'Other Expenses'
  ];

  const handleSyncToGoogleSheets = async (transactionData: Transaction) => {
    const webhookUrl = localStorage.getItem('google_sheets_webhook');
    
    if (!webhookUrl) {
      toast({
        title: "Google Sheets Not Configured",
        description: "Please configure Google Sheets integration in Reports section.",
        variant: "destructive"
      });
      return false;
    }

    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        mode: "no-cors",
        body: JSON.stringify({
          action: "add_transaction",
          timestamp: new Date().toISOString(),
          data: {
            date: transactionData.date,
            type: transactionData.type,
            category: transactionData.category,
            description: transactionData.description,
            income: transactionData.type === 'income' ? transactionData.amount : 0,
            expense: transactionData.type === 'expense' ? transactionData.amount : 0,
            account: transactionData.account,
            reference: transactionData.reference
          }
        }),
      });

      return true;
    } catch (error) {
      console.error("Error syncing to Google Sheets:", error);
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Create new transaction
      const newTransaction: Transaction = {
        id: Date.now().toString(),
        ...transaction,
        date: format(selectedDate, 'yyyy-MM-dd')
      };

      // Simulate saving transaction locally
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Sync to Google Sheets if enabled
      if (autoSyncToSheets) {
        const syncSuccess = await handleSyncToGoogleSheets(newTransaction);
        
        if (syncSuccess) {
          toast({
            title: "Transaction Added & Synced",
            description: "Transaction saved and synced to Google Sheets successfully.",
          });
        } else {
          toast({
            title: "Transaction Added",
            description: "Transaction saved locally. Google Sheets sync failed.",
            variant: "destructive"
          });
        }
      } else {
        toast({
          title: "Transaction Added",
          description: "Transaction saved successfully.",
        });
      }

      // Reset form
      setTransaction({
        date: new Date().toISOString().split('T')[0],
        type: 'income',
        category: '',
        description: '',
        amount: 0,
        account: 'cash',
        reference: ''
      });
      setSelectedDate(new Date());

    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save transaction. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-primary">Transactions</h1>
          <p className="text-muted-foreground">Add and manage your financial transactions</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Transaction Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Add New Transaction
            </CardTitle>
            <CardDescription>Record a new income or expense transaction</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Date */}
              <div className="space-y-2">
                <Label>Transaction Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !selectedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => date && setSelectedDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Type and Account */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select 
                    value={transaction.type} 
                    onValueChange={(value: 'income' | 'expense') => 
                      setTransaction(prev => ({ ...prev, type: value, category: '' }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Account</Label>
                  <Select 
                    value={transaction.account} 
                    onValueChange={(value) => setTransaction(prev => ({ ...prev, account: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank">Bank Account</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Category */}
              <div className="space-y-2">
                <Label>Category</Label>
                <Select 
                  value={transaction.category} 
                  onValueChange={(value) => setTransaction(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {(transaction.type === 'income' ? incomeCategories : expenseCategories).map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Amount */}
              <div className="space-y-2">
                <Label>Amount (₹)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={transaction.amount || ''}
                    onChange={(e) => setTransaction(prev => ({ ...prev, amount: Number(e.target.value) }))}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Enter transaction description..."
                  value={transaction.description}
                  onChange={(e) => setTransaction(prev => ({ ...prev, description: e.target.value }))}
                  required
                />
              </div>

              {/* Reference */}
              <div className="space-y-2">
                <Label>Reference (Optional)</Label>
                <Input
                  placeholder="Invoice number, receipt ID, etc."
                  value={transaction.reference}
                  onChange={(e) => setTransaction(prev => ({ ...prev, reference: e.target.value }))}
                />
              </div>

              {/* Auto Sync Option */}
              <div className="flex items-center justify-between p-4 bg-accent rounded-lg">
                <div className="space-y-0.5">
                  <Label htmlFor="autoSync">Auto-sync to Google Sheets</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically send this transaction to your Google Sheet
                  </p>
                </div>
                <Switch
                  id="autoSync"
                  checked={autoSyncToSheets}
                  onCheckedChange={setAutoSyncToSheets}
                />
              </div>

              {/* Submit Button */}
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Upload className="h-4 w-4 mr-2 animate-spin" />
                    {autoSyncToSheets ? 'Saving & Syncing...' : 'Saving...'}
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Add Transaction
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>Your latest financial activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((txn) => (
                <div key={txn.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        txn.type === 'income' 
                          ? 'bg-success/10 text-success' 
                          : 'bg-warning/10 text-warning'
                      }`}>
                        {txn.type}
                      </span>
                      <span className="text-sm text-muted-foreground">{txn.category}</span>
                    </div>
                    <p className="font-medium">{txn.description}</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(txn.date), 'dd/MM/yyyy')} • {txn.account}
                      {txn.reference && ` • ${txn.reference}`}
                    </p>
                  </div>
                  <div className={`text-right font-semibold ${
                    txn.type === 'income' ? 'text-success' : 'text-warning'
                  }`}>
                    {txn.type === 'income' ? '+' : '-'}₹{txn.amount.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Transactions;