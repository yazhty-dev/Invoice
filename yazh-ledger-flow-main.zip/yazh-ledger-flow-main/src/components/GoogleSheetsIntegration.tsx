import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { 
  Settings, 
  Link as LinkIcon, 
  Upload, 
  CheckCircle,
  AlertCircle,
  ExternalLink,
  RefreshCw
} from 'lucide-react';

interface GoogleSheetsConfig {
  webhookUrl: string;
  sheetName: string;
  autoSync: boolean;
  syncInterval: number;
  lastSync: string | null;
}

interface LedgerData {
  date: string;
  type: string;
  description: string;
  income: number;
  expense: number;
  balance: number;
  account: string;
}

const GoogleSheetsIntegration = () => {
  const [config, setConfig] = useState<GoogleSheetsConfig>({
    webhookUrl: localStorage.getItem('google_sheets_webhook') || '',
    sheetName: 'Yazh Ledger Data',
    autoSync: false,
    syncInterval: 60,
    lastSync: localStorage.getItem('last_sync_time')
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [testData, setTestData] = useState<LedgerData[]>([
    {
      date: new Date().toISOString().split('T')[0],
      type: 'Income',
      description: 'Test Transaction - Printing Services',
      income: 5500,
      expense: 0,
      balance: 45500,
      account: 'Cash'
    },
    {
      date: new Date().toISOString().split('T')[0],
      type: 'Expense',
      description: 'Test Transaction - Paper Purchase',
      income: 0,
      expense: 2000,
      balance: 43500,
      account: 'Cash'
    }
  ]);

  const handleSaveConfig = () => {
    localStorage.setItem('google_sheets_webhook', config.webhookUrl);
    localStorage.setItem('sheets_config', JSON.stringify(config));
    
    toast({
      title: "Configuration Saved",
      description: "Google Sheets integration settings have been saved.",
    });
  };

  const handleTestConnection = async () => {
    if (!config.webhookUrl) {
      toast({
        title: "Error",
        description: "Please enter your Zapier webhook URL first",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(config.webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        mode: "no-cors",
        body: JSON.stringify({
          action: "test_connection",
          timestamp: new Date().toISOString(),
          source: "Yazh Prints and Frames Ledger",
          message: "Test connection from ledger management system"
        }),
      });

      toast({
        title: "Test Request Sent",
        description: "Check your Zapier history to confirm the connection is working.",
      });
    } catch (error) {
      console.error("Error testing connection:", error);
      toast({
        title: "Connection Test Failed",
        description: "Please check your webhook URL and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSyncData = async (data: LedgerData[] = testData) => {
    if (!config.webhookUrl) {
      toast({
        title: "Error",
        description: "Please configure your Zapier webhook URL first",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(config.webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        mode: "no-cors",
        body: JSON.stringify({
          action: "sync_ledger_data",
          timestamp: new Date().toISOString(),
          sheetName: config.sheetName,
          data: data,
          summary: {
            totalIncome: data.reduce((sum, item) => sum + item.income, 0),
            totalExpense: data.reduce((sum, item) => sum + item.expense, 0),
            recordCount: data.length
          }
        }),
      });

      const syncTime = new Date().toISOString();
      setConfig(prev => ({ ...prev, lastSync: syncTime }));
      localStorage.setItem('last_sync_time', syncTime);

      toast({
        title: "Data Sync Initiated",
        description: `${data.length} records sent to Google Sheets via Zapier.`,
      });
    } catch (error) {
      console.error("Error syncing data:", error);
      toast({
        title: "Sync Failed",
        description: "Failed to sync data to Google Sheets. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-primary">Google Sheets Integration</h2>
          <p className="text-muted-foreground">Connect your ledger with Google Sheets via Zapier</p>
        </div>
        <Badge variant={config.webhookUrl ? "default" : "secondary"}>
          {config.webhookUrl ? "Configured" : "Not Configured"}
        </Badge>
      </div>

      {/* Setup Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Setup Instructions
          </CardTitle>
          <CardDescription>Follow these steps to connect your ledger with Google Sheets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">1</div>
              <div>
                <h4 className="font-medium">Create a Zapier Account</h4>
                <p className="text-sm text-muted-foreground">Sign up at zapier.com if you don't have an account</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">2</div>
              <div>
                <h4 className="font-medium">Create a New Zap</h4>
                <p className="text-sm text-muted-foreground">
                  Trigger: Webhooks by Zapier → Catch Hook<br/>
                  Action: Google Sheets → Create Spreadsheet Row
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">3</div>
              <div>
                <h4 className="font-medium">Copy Webhook URL</h4>
                <p className="text-sm text-muted-foreground">Copy the webhook URL from Zapier and paste it below</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">4</div>
              <div>
                <h4 className="font-medium">Configure Google Sheets</h4>
                <p className="text-sm text-muted-foreground">
                  Map the data fields: Date, Type, Description, Income, Expense, Balance, Account
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-accent rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <ExternalLink className="h-4 w-4" />
              <span className="font-medium">Need Help?</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Check out Zapier's documentation on connecting webhooks to Google Sheets for detailed setup instructions.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LinkIcon className="h-5 w-5" />
            Webhook Configuration
          </CardTitle>
          <CardDescription>Configure your Zapier webhook connection</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="webhookUrl">Zapier Webhook URL</Label>
            <Input
              id="webhookUrl"
              type="url"
              placeholder="https://hooks.zapier.com/hooks/catch/..."
              value={config.webhookUrl}
              onChange={(e) => setConfig(prev => ({ ...prev, webhookUrl: e.target.value }))}
            />
            <p className="text-xs text-muted-foreground">
              This URL will be used to send ledger data to your Google Sheet
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sheetName">Google Sheet Name</Label>
            <Input
              id="sheetName"
              placeholder="Yazh Ledger Data"
              value={config.sheetName}
              onChange={(e) => setConfig(prev => ({ ...prev, sheetName: e.target.value }))}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="autoSync">Auto Sync</Label>
              <p className="text-sm text-muted-foreground">Automatically sync data periodically</p>
            </div>
            <Switch
              id="autoSync"
              checked={config.autoSync}
              onCheckedChange={(checked) => setConfig(prev => ({ ...prev, autoSync: checked }))}
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSaveConfig} variant="outline">
              Save Configuration
            </Button>
            <Button onClick={handleTestConnection} disabled={isLoading || !config.webhookUrl}>
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Test Connection
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Data Sync */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Data Sync
          </CardTitle>
          <CardDescription>Sync your ledger data to Google Sheets</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {config.lastSync && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <CheckCircle className="h-4 w-4 text-success" />
              Last synced: {new Date(config.lastSync).toLocaleString()}
            </div>
          )}

          <div className="p-4 bg-muted rounded-lg">
            <h4 className="font-medium mb-2">Sample Data Preview</h4>
            <div className="text-sm space-y-1">
              {testData.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <span>{item.description}</span>
                  <span className={item.income > 0 ? 'text-success' : 'text-warning'}>
                    ₹{(item.income || item.expense).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={() => handleSyncData(testData)} 
              disabled={isLoading || !config.webhookUrl}
              className="flex-1"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Sync Sample Data
                </>
              )}
            </Button>
            <Button 
              variant="outline" 
              onClick={() => handleSyncData([])} 
              disabled={isLoading || !config.webhookUrl}
            >
              Sync All Data
            </Button>
          </div>

          <div className="p-3 bg-accent rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-warning mt-0.5" />
              <div className="text-sm">
                <p className="font-medium">Data Format</p>
                <p className="text-muted-foreground">
                  Data will be sent as JSON with fields: Date, Type, Description, Income, Expense, Balance, Account
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GoogleSheetsIntegration;