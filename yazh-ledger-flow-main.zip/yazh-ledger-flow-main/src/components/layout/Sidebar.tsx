import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  CreditCard, 
  FileText, 
  TrendingUp,
  Settings,
  PlusCircle,
  DollarSign,
  BarChart3
} from 'lucide-react';

const navigation = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    name: 'Accounts',
    href: '/accounts',
    icon: CreditCard,
  },
  {
    name: 'Transactions',
    href: '/transactions',
    icon: DollarSign,
  },
  {
    name: 'Debit Notes',
    href: '/debit-notes',
    icon: FileText,
  },
  {
    name: 'Reports',
    href: '/reports',
    icon: BarChart3,
  },
  {
    name: 'Analytics',
    href: '/analytics',
    icon: TrendingUp,
  },
];

const quickActions = [
  {
    name: 'New Transaction',
    href: '/transactions/new',
    icon: PlusCircle,
  },
  {
    name: 'New Debit Note',
    href: '/debit-notes/new',
    icon: FileText,
  },
];

const Sidebar = () => {
  const location = useLocation();

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col h-full">
      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        <div className="space-y-1">
          <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Main Menu
          </h3>
          {navigation.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <NavLink
                key={item.name}
                to={item.href}
                className={cn(
                  'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-foreground hover:bg-accent hover:text-accent-foreground'
                )}
              >
                <item.icon
                  className="mr-3 h-5 w-5 flex-shrink-0"
                />
                {item.name}
              </NavLink>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="pt-6 space-y-1">
          <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Quick Actions
          </h3>
          {quickActions.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className="group flex items-center px-3 py-2 text-sm font-medium rounded-lg text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
            >
              <item.icon className="mr-3 h-5 w-5 flex-shrink-0" />
              {item.name}
            </NavLink>
          ))}
        </div>
      </nav>

      {/* Settings */}
      <div className="p-4 border-t border-border">
        <NavLink
          to="/settings"
          className="group flex items-center px-3 py-2 text-sm font-medium rounded-lg text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
        >
          <Settings className="mr-3 h-5 w-5 flex-shrink-0" />
          Settings
        </NavLink>
      </div>
    </div>
  );
};

export default Sidebar;